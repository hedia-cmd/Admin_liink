declare module "./dataProvider" {
    import { DataProvider } from "react-admin";
    const dp: DataProvider;
    export default dp;
  }
  
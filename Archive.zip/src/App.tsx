// src/App.tsx
import * as React from "react";
import {
  Admin,
  Resource,
  List,
  Datagrid,
  TextField,
  Edit,
  SimpleForm,
  TextInput,
  Create,
  NumberInput,
  ReferenceInput,
  SelectInput,
} from "react-admin";
import dataProvider from "./dataProvider";

// === Questionnaires ===
const QuestionnaireList = () => (
  <List>
    <Datagrid rowClick="edit">
      <TextField source="id" />
      <TextField source="title" />
    </Datagrid>
  </List>
);
const QuestionnaireEdit = () => (
  <Edit>
    <SimpleForm>
      <TextInput source="title" />
    </SimpleForm>
  </Edit>
);
const QuestionnaireCreate = () => (
  <Create>
    <SimpleForm>
      <TextInput source="title" required />
    </SimpleForm>
  </Create>
);

// === Questions ===
const QuestionList = () => (
  <List>
    <Datagrid rowClick="edit">
      <TextField source="id" />
      <TextField source="text" />
      <TextField source="order_index" />
      <TextField source="questionnaire_id" />
    </Datagrid>
  </List>
);
const QuestionEdit = () => (
  <Edit>
    <SimpleForm>
      <TextInput source="text" />
      <NumberInput source="order_index" />
      <ReferenceInput source="questionnaire_id" reference="questionnaires">
        <SelectInput optionText="title" />
      </ReferenceInput>
    </SimpleForm>
  </Edit>
);
const QuestionCreate = () => (
  <Create>
    <SimpleForm>
      <TextInput source="text" required />
      <NumberInput source="order_index" />
      <ReferenceInput source="questionnaire_id" reference="questionnaires">
        <SelectInput optionText="title" />
      </ReferenceInput>
    </SimpleForm>
  </Create>
);

// === Choices ===
const ChoiceList = () => (
  <List>
    <Datagrid rowClick="edit">
      <TextField source="id" />
      <TextField source="text" />
      <TextField source="value" />
      <TextField source="question_id" />
    </Datagrid>
  </List>
);
const ChoiceEdit = () => (
  <Edit>
    <SimpleForm>
      <TextInput source="text" />
      <NumberInput source="value" />
      <ReferenceInput source="question_id" reference="questions">
        <SelectInput optionText="text" />
      </ReferenceInput>
    </SimpleForm>
  </Edit>
);
const ChoiceCreate = () => (
  <Create>
    <SimpleForm>
      <TextInput source="text" required />
      <NumberInput source="value" />
      <ReferenceInput source="question_id" reference="questions">
        <SelectInput optionText="text" />
      </ReferenceInput>
    </SimpleForm>
  </Create>
);

// === Spots ===
const SpotList = () => (
  <List>
    <Datagrid rowClick="edit">
      <TextField source="id" />
      <TextField source="name" />
      <TextField source="lat" />
      <TextField source="lng" />
      <TextField source="questionnaire_id" />
    </Datagrid>
  </List>
);
const SpotEdit = () => (
  <Edit>
    <SimpleForm>
      <TextInput source="name" />
      <NumberInput source="lat" />
      <NumberInput source="lng" />
      <ReferenceInput source="questionnaire_id" reference="questionnaires">
        <SelectInput optionText="title" />
      </ReferenceInput>
    </SimpleForm>
  </Edit>
);
const SpotCreate = () => (
  <Create>
    <SimpleForm>
      <TextInput source="name" required />
      <NumberInput source="lat" />
      <NumberInput source="lng" />
      <ReferenceInput source="questionnaire_id" reference="questionnaires">
        <SelectInput optionText="title" />
      </ReferenceInput>
    </SimpleForm>
  </Create>
);

export default function App() {
  return (
    <Admin dataProvider={dataProvider}>
      <Resource
        name="questionnaires"
        list={QuestionnaireList}
        edit={QuestionnaireEdit}
        create={QuestionnaireCreate}
      />
      <Resource
        name="questions"
        list={QuestionList}
        edit={QuestionEdit}
        create={QuestionCreate}
      />
      <Resource
        name="choices"
        list={ChoiceList}
        edit={ChoiceEdit}
        create={ChoiceCreate}
      />
      <Resource name="spots" list={SpotList} edit={SpotEdit} create={SpotCreate} />
    </Admin>
  );
}
